import React from "react";

const Detail2 = () => {
  return <div>상세보기2</div>;
};

export default Detail2;

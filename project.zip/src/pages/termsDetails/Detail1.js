import React from "react";

const Detail1 = () => {
  return <div>상세보기1</div>;
};

export default Detail1;

import React from "react";

const PaymentCoupon = () => {
  return <div>PaymentCoupon</div>;
};

export default PaymentCoupon;

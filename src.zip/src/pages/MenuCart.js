import React from "react";

const MenuCart = () => {
  return <div>MenuCart</div>;
};

export default MenuCart;

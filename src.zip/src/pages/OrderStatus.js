import React from "react";

const OrderStatus = () => {
  return <div>OrderStatus</div>;
};

export default OrderStatus;

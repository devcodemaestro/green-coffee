import React from "react";

const Resign = () => {
  return <div>Resign</div>;
};

export default Resign;

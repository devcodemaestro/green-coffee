import React from "react";
import { BannerWrap } from "../../styles/OrderStyle";

const Banner = () => {
  return <BannerWrap>Banner</BannerWrap>;
};

export default Banner;

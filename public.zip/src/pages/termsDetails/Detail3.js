import React from "react";

const Detail3 = () => {
  return <div>상세보기3</div>;
};

export default Detail3;
